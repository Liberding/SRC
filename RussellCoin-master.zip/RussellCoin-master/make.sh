make

strip src/*.exe
strip src/qt/*.exe