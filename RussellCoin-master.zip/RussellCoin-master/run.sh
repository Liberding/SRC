./autogen.sh


CPPFLAGS="-I/c/deps/db-4.8.30.NC/build_unix \
-I/c/deps/boost_1_60_0 \
-I/c/deps/openssl-1.0.11/include \
-I/c/deps \
-I/c/deps/protobuf-2.6.1/src \
-I/c/deps/libpng-1.6.16 \
-I/c/deps/qrencode-3.4.4 \
-I/c/deps/gmp-6.0.0" \
LDFLAGS="-L/c/deps/db-4.8.30.NC/build_unix \
-L/c/deps/boost_1_60_0/stage/lib \
-L/c/deps/openssl-1.0.11 \
-L/c/deps/miniupnpc \
-L/c/deps/protobuf-2.6.1/src/.libs \
-L/c/deps/libpng-1.6.16/.libs \
-L/c/deps/qrencode-3.4.4/.libs \
-L/c/deps/gmp-6.0.0/.libs" \
./configure --prefix=/c/dash/dash-master-build/ \
--disable-upnp-default \
--disable-tests \
--with-qt-incdir=/c/Qt/5.3.2/include \
--with-qt-libdir=/c/Qt/5.3.2/lib \
--with-qt-plugindir=/c/Qt/5.3.2/plugins \
--with-qt-bindir=/c/Qt/5.3.2/bin \
--with-boost-system=mgw49-mt-s-1_60 \
--with-boost-filesystem=mgw49-mt-s-1_60 \
--with-boost-program-options=mgw49-mt-s-1_60 \
--with-boost-thread=mgw49-mt-s-1_60 \
--with-boost-chrono=mgw49-mt-s-1_60 \
--with-protoc-bindir=/c/deps/protobuf-2.6.1/src