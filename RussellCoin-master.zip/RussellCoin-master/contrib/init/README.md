Sample configuration files for:

SystemD: dashd.service
Upstart: dashd.conf
OpenRC:  dashd.openrc
         dashd.openrcconf

have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
